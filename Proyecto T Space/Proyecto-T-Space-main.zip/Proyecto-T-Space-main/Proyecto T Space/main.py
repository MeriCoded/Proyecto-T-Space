import sys
import pygame
import time
import math
#import collisions
from random import randint
from settings import Settings
from estelar import Estelar
from meteor_v2 import load_meteor_images, Meteor
from space import Space

class Window:
    def __init__(self):
        pygame.init()
        self.settings = Settings()
        self.screen = pygame.display.set_mode((self.settings.screen_width, self.settings.screen_height))
        pygame.display.set_caption("")
        self.clock = pygame.time.Clock()
        self.screen_rect = self.screen.get_rect()
        
        self.estelar = Estelar(self)
        self.bullets = pygame.sprite.Group()
        self.space = Space(self.screen, self.settings)
        self.meteors_grandes = pygame.sprite.Group()
        self.last_meteor_time = pygame.time.get_ticks()
        self.meteor_delay = 600  # milisegundos entre meteoritos
        
        #Cargar las imágenes de los meteoritos
        load_meteor_images()    
        
    def get_meteor_type(self): #Devuelve el tipo de meteorito según el tiempo transcurrido
        elapsed_time = pygame.time.get_ticks() // 1000 
        if elapsed_time < 10:
            return "M1"
        elif elapsed_time < 20:
            return "M2"
        elif elapsed_time < 30:
            return "M3"
        else:
            return "M4"       
   
    def run(self):
        running = True
        
        while running:
            delta_time = self.clock.tick(self.settings.fps) / 1000
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
            
            current_time = pygame.time.get_ticks()
            if current_time - self.last_meteor_time > self.meteor_delay:
                if len(self.meteors_grandes) < 12:
                    tipo = self.get_meteor_type()
                    x = randint(0, self.settings.screen_width)
                    y = randint(-200, -100)
                    Meteor(tipo, (x, y), (self.meteors_grandes,))
                self.last_meteor_time = current_time

            self.estelar.update_estelar()
            self.bullets.update()
            self.space.draw()
            self.meteors_grandes.update(delta_time)

            pygame.sprite.groupcollide(self.meteors_grandes, self.bullets, True, True)

            self.estelar.draw_estelar()
            self.bullets.draw(self.screen)
            for bullet in self.bullets:
                bullet.draw_bullet()
            self.meteors_grandes.draw(self.screen)

            pygame.display.flip()

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    ventana = Window()
    ventana.run()
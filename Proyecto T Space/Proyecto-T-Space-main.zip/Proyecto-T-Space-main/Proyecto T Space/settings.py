import pygame

class Settings:
    def __init__(self):
        self.screen_width = 360
        self.screen_height = 640
        self.fps = 60
        self.estelar_speed = 5
        self.bullet_speed = 10
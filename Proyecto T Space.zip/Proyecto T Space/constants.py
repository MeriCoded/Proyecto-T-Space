M1_TIME = 5 #reemplazar por 60
M2_TIME = 10 #reemplazar por 120
M3_TIME = 15 #reemplazar por 180
M4_TIME = 20 #reemplazar por 240